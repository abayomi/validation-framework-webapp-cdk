const nextConfig = {
    output: 'export',
    distDir: 'dist',
  }
 
  module.exports = nextConfig;